#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
* <h3>${PROJECT_NAME}</h3>
* <p>${description}</p>
* @author : zwmuzhi
* @date : ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}
**/
public class ${NAME} {
}
